### Running the application
https://skalman.github.io/UglifyJS-online/

Global Dependencies:
NodeJS, NPM, Gulp

****** RUN 
$ gulp templates
$ gulp appscripts
$ npm run start

<!-- This readme if for after deployment concatination -->
1. NPM Install [Needed initially for Gulp dependency]
2. Open Terminal in main folder
3. Run 'gulp serve' 
4. Navigate to localhost:8065

{
  "name": "SSCEexamsUI",
  "version": "0.0.1",
  "description": "SSCE Examinations Angular SPA.",
  "directories": {
    "test": "test"
  },
  "scripts": {
    "test": "karma start karma.conf.js",
    "start": "node scripts/web-server.js",
    "serve": "gulp serve"
  },
  "author": "Adetunji Oduyela",
  "license": "ISC",
  "dependencies": {
    "angular": "^1.4.4",
    "angular-animate": "^1.5.8",
    "angular-cookies": "^1.4.4",
    "angular-moment": "^1.0.0-beta.6",
    "angular-resource": "^1.4.4",
    "angular-ui-bootstrap": "^0.13.4",
    "bcrypt-nodejs": "0.0.3",
    "body-parser": "1.13.1",
    "bootstrap": "^3.3.7",
    "cors": "^2.8.3",
    "download": "^4.4.3",
    "event-stream": "^3.3.4",
    "express": "^4.14.0",
    "font-awesome": "^4.4.0",
    "gulp-htmlmin": "^3.0.0",
    "gulp-minify": "0.0.7",
    "jquery": "^2.1.4",
    "jsonwebtoken": "^7.1.9",
    "karma": "^0.13.22",
    "lodash": "^3.10.1",
    "moment": "^2.14.1",
    "mongoose": "^4.8.1",
    "morgan": "^1.7.0",
    "ng-file-upload": "^12.2.13",
    "parse-link-header": "^0.4.1",
    "underscore": "^1.8.3"
  },
  "devDependencies": {
    "bower": "^1.8.0",
    "del": "^2.2.2",
    "event-stream": "^3.3.4",
    "gulp": "^3.9.1",
    "gulp-angular-templatecache": "^2.0.0",
    "gulp-concat": "^2.6.1",
    "gulp-develop-server": "^0.5.2",
    "gulp-gzip": "^1.4.0",
    "gulp-htmlmin": "^3.0.0",
    "gulp-jshint": "^2.0.4",
    "gulp-minify": "0.0.7",
    "gulp-minify-css": "^1.2.4",
    "gulp-rename": "^1.2.2",
    "gulp-uglify": "^2.1.2",
    "gulp-watch": "^4.3.11",
    "jshint": "^2.9.4",
    "jshint-stylish": "^2.2.1"
  }
}
