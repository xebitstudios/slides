(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .factory('AuthService', AuthService);

    // AuthService.$inject = ['$http', '$q', 'growl', '$rootScope', 'window', 'ConfigService'];

    /* @ngInject */
    function AuthService($http, $q, growl, $rootScope, window, ConfigService) {

        return {
            setUserId: setUserId
        };

        function httpPromise(vobj) {
            var deferred = $q.defer();
            $http(vobj)
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function() {
                    deferred.reject();
                });
            return deferred.promise;
        };
        
        function setUserId(urlpath) {
            console.log('ConfigService.getApiBaseRoute is: ' + ConfigService.getApiBaseRoute());
            // urlBase = location.origin;//'https://beep.com:10443/';
            var vObj = {
                method: 'GET',
                url: urlpath,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8'
                        // 'Authorization': $rootScope.token || window.sessionStorage.act
                }
            };
            return httpPromise(vObj);
        };
    }
})();