(function() {
	'use strict';

	angular
        .module('ssceexamsuiApp')
		.factory('SaveexamService', SaveexamService);

		// SaveexamService.$inject = ['window'];

		/* @ngInject */
		function SaveexamService(window) {

			return {
				saveExam: saveExam,
				getToken: getToken
			};

			function getToken() {
				if(window.sessionStorage.act) {
					return window.sessionStorage.act;
				} else {
					return '';
				}
			};

			function setToken(val) {
				window.sessionStorage.act = val;
			};
		}
})();

// })();
