(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .factory('DataStore', DataStore);

    // DataStore.$inject = ['$rootScope', 'window'];

    /* @ngInject */
    function DataStore($rootScope, window) {

        var logCount = $rootScope.logCount || 0;

        // sessionStorage.removeItem("key");
        // sessionStorage.clear();

        return {
            setExams: setExams,
            getUserProfile: getUserProfile,
            setUserProfile: setUserProfile,
            getUserSchProfile: getUserSchProfile,
            setUserSchProfile: setUserSchProfile,
            getUserToprow: getUserToprow,
            setUserToprow: setUserToprow,
            getChart1: getChart1,
            setChart1: setChart1,
            getChart2: getChart2,
            setChart2: setChart2,
            getChart3: getChart3,
            setChart3: setChart3,
            getChart4: getChart4,
            setChart4: setChart4,
            getChart5: getChart5,
            setChart5: setChart5,
            getChart6: getChart6,
            setChart6: setChart6,
            getLogs: getLogs,
            setLogs: setLogs,
            setSavedExam: setSavedExam,
            getSavedExam: getSavedExam,
            getSavedExams: getSavedExams,
            removeSavedExam: removeSavedExam,
            getExamRestart: getExamRestart,
            setExamRestart: setExamRestart,
            getExamContinue: getExamContinue,
            setExamContinue: setExamContinue,
            getpwd: getpwd,
            setpwd: setpwd,
            getSectionB: getSectionB,
            setSectionB: setSectionB
        };

        function setExams(txt, val) {
            // maths, 'maths_1988_sectionB', 'physics_1988_sectionB', 'chemistry_1988_sectionB', 'biology_1988_sectionB'
            // 'biology_1988_sectionB', 'english_1988_sectionB', 'economics_1988_sectionB', 'agricsci_1988_sectionB',
            // 'commerce_1988_sectionB', 'government_1988_sectionB', 'litineng_1988_sectionB'
            window.sessionStorage.setItem(txt, val);
        };

        function setSectionB(subj, yr, val) {
            window.sessionStorage.setItem(subj + '_' + yr + '_sectionB', val);
        };

        function getSectionB(subj, yr) {
            console.log("getting the exam set for: " + subj + '_' + yr + '_sectionB');
            console.log(window.sessionStorage.getItem(subj + '_' + yr + '_sectionB'));
            return window.sessionStorage.getItem(subj + '_' + yr + '_sectionB');
        };

        function setpwd(val) {
            window.sessionStorage.password = val;
        };

        function getpwd() {
            return window.sessionStorage.password || null;
        };

        function setExamRestart(val) {
            window.sessionStorage.examRestart = JSON.stringify(val);
        };

        function getExamRestart() {
            return JSON.parse(window.sessionStorage.examRestart || null);
        };

        function setExamContinue(val) {
            window.sessionStorage.examContinue = JSON.stringify(val);
        };

        function getExamContinue() {
            return JSON.parse(window.sessionStorage.examContinue || null);
        };

        function setUserProfile(val) {
            console.log('setUserProfile: ');
            window.sessionStorage.userprofile = val;
        };

        function setUserSchProfile(val) {
            console.log('setUserSchProfile: ');
            window.sessionStorage.userSchprofile = val;
        };

        function getUserProfile() {
            console.log('getUserProfile: ');
            return window.sessionStorage.userprofile;
        };

        function getUserSchProfile() {
            console.log('getUserSchProfile: ');
            return window.sessionStorage.userSchprofile;
        };

        function setUserToprow(val) {
            console.log('setUserToprow: ');
            window.sessionStorage.toprow = val;
        };

        function getUserToprow() {
            console.log('getUserToprow: ');
            return window.sessionStorage.toprow;
        };

        function getChart1(userid, subj, yr) {
            console.log('getChart1: ');
            return window.sessionStorage.getItem(userid + '-' + subj + '-' + yr + '-chart1');
        };

        function setChart1(userid, subj, yr, val) {
            console.log('setChart1: ');
            window.sessionStorage.setItem(userid + '-' + subj + '-' + yr + '-chart1', val);
        };

        function getChart2(userid, subj, yr) {
            console.log('getChart2: ');
            return window.sessionStorage.getItem(userid + '-' + subj + '-' + yr + '-chart2');
        };

        function setChart2(userid, subj, yr, val) {
            console.log('setChart2: ');
            window.sessionStorage.setItem(userid + '-' + subj + '-' + yr + '-chart2', val);           
        };

        function getChart3(userid, yr) {
            console.log('getChart3: ');
            return window.sessionStorage.getItem(userid + '-' + yr + '-chart3');
        };

        function setChart3(userid, yr, val) {
            console.log('setChart3: ');
            window.sessionStorage.setItem(userid + '-' + yr + '-chart3', val);           
        };

        function getChart4(userid, tv) {
            console.log('getChart4: ');
            return window.sessionStorage.getItem(userid + '-' + tv + '-chart4');
        };

        function setChart4(userid, tv, val) {
            console.log('setChart4: ');
            window.sessionStorage.setItem(userid + '-' + tv + '-chart4', val);           
        };

        function getChart5(userid, subj) {
            console.log('getChart5: ');
            return window.sessionStorage.getItem(userid + '-' + subj + '-chart5');
        };

        function setChart5(userid, subj, val) {
            console.log('setChart5: ');
            window.sessionStorage.setItem(userid + '-' + subj + '-chart5', val);           
        };

        function getChart6(userid, subj) {
            console.log('getChart6: ');
            return window.sessionStorage.getItem(userid + '-' + subj + '-chart6');
        };

        function setChart6(userid, subj, val) {
            console.log('setChart6: ');
            window.sessionStorage.setItem(userid + '-' + subj + '-chart6', val);           
        };
        
        function getLogs(userid) {
            console.log('getLogs: ');
            // return JSON.parse(window.sessionStorage.getItem(userid + '-logs'));
            // return window.sessionStorage.getItem(userid + '-logs');
            console.log("getLogs done...");
            console.log(userid + '-logs');
            return JSON.parse(window.sessionStorage.getItem(userid + '-logs'));
        };

        function setLogs(userid, val) {
            console.log('setLogs: ');
            // window.sessionStorage.setItem(userid + '-logs', val); 
            window.sessionStorage.setItem(userid + '-logs', val); 
            console.log("setLogs done...");
            console.log(JSON.parse(val));
        };

        function getSavedExam(val) {
            console.log('getExamScore: ');
            return window.sessionStorage.getItem(val);
        };

        function getSavedExams(userid) {
            console.log('getExamScores: ');
            console.log(Object.keys(window.sessionStorage)); // gives back the full string array
            return _.filter(Object.keys(window.sessionStorage), function(str) {
                if(str.indexOf('svdexms') != -1) {
                    // console.log(getSavedExam(str)); // gives you the saved answer string
                    return str;
                }
            });// gives back the filtered string array
        };

        function setSavedExam(userid, val) {
            console.log('setExamScore: ');
            console.log("val.exmid + val.examyear is: " + val.exmid + ", " + val.examyear);
            window.sessionStorage.setItem(userid + '-svdexms:' + getSubjectName(val.exmid) + '-' + val.examyear, val.tmlft + '-' + getDate() + '-' + val.qArry);                               
            // console.log(getSavedExams(userid));
        };

        function removeSavedExam(val) {
            console.log("removing Saved exam: " + val);
            window.sessionStorage.removeItem(val);
        };

        function getDate() {
            var myDate = new Date();
            return "L_" + (myDate.getMonth() + 1) + "_" +
                 myDate.getDate() + "_" + 
                 myDate.getFullYear() + '_' + 
                 myDate.getHours() + "_" + 
                 myDate.getMinutes() + "_" + 
                 myDate.getSeconds() + "_" + 
                 myDate.getMilliseconds();
        };

        function getSubjectName(val) {
            if(val=="comm_B") {
                return "Commerce";
            } else if(val=="econ_B") {
                return "Economics";
            } else if(val=="eng_B") {
                return "English";
            } else if(val=="geo_B") {
                return "Geography";
            } else if(val=="govt_B") {
                return "Government";
            } else if(val=="liteng_B") {
                return "Lit. in English";
            } else if(val=="Math_B") {
                return "Mathematics";
            } else if(val=="bio_B") {
                return "Biology";
            } else if(val=="chem_B") {
                return "Chemistry";
            } else if(val=="agricsci_B") {
                return "Agric. Science";
            } else if(val=="phy_B") {
                return "Physics";
            }
        };
    }
})();