(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('TestcenterController', TestcenterController);

    // TestcenterController.$inject = ['$scope', '$log', '$location', 'DataStore', '$controller', '$rootScope', 'ConfigService', 'ApiService', 'HeaderService', 'growl', '$timeout', 'LoggingService'];

    /* @ngInject */
    function TestcenterController($scope, $log, $location, DataStore, $controller, $rootScope, ConfigService, ApiService, HeaderService, growl, $timeout, LoggingService) {

        $controller('BaseController', {$scope: $scope});
        $rootScope.baseRoute = '';
        var baseRoute = '';
        $scope.savedExams = [];
        $scope.svdexmCount = 0;
        $scope.svdexmmodal = {
            modalShown: false
        };

        $scope.btnClose = function() {
          LoggingService.postTrack("tstc-btnClose");
          console.log("I was clicked...");
          $('div.ng-modal-dialog div.ng-modal-close div i.fa').click();
          $scope.svdexmmodal.modalShown = false;
        };

        $scope.getSavedExams = function() {
          LoggingService.postTrack("getSavedExams");
          return DataStore.getSavedExams();
        };

        $scope.inTestcenter = function() {
            console.log('Now in the Testcenter page!');
        };

        $scope.setRealtimeScore = function() {
          LoggingService.postTrack("setRealtimeScore");
          console.log('$scope.setRealtimeScore() called!');
          $('#rtscore').prop('checked', !$('#rtscore').prop('checked'));
          $rootScope.rtscore = $('#rtscore').prop('checked');
        };

        $scope.continueExams = function() {
          console.log("DataStore.addLog();:...");
          LoggingService.postTrack("continueExams");
          // DataStore.addLog($rootScope.userid, "L_1_3_5_7_9_11");
          console.log("ApiService.sendLogs();:....");
          ApiService.sendLogs();
          console.log('You have selected to continue saved exams.');
          $scope.savedExams = [];
          $scope.savedExams = DataStore.getSavedExams();
          for(var i=0;i < $scope.savedExams.length; i++) {
            $scope.savedExams[i] = ((($scope.savedExams[i]).split(':'))[1]).replace('-', ' ');
          }
          $scope.svdexmCount = $scope.savedExams.length;
          console.log("$scope.savedExams: ");
          $scope.svdexmmodal.modalShown = true;
        };

        $scope.continueExm = function() {
          LoggingService.postTrack("continueExm");
          console.log('You have selected to continue saved exam.');
          for(var i=0;i < $scope.savedExams.length; i++) {
            if($('#svdexmv' + i).is(':checked')) {
              console.log('continuing exam: ' + $scope.savedExams[i].split(' ').join('-'));
              console.log("window.sessionStorage.getItem($rootScope.userid + '-svdexms:' + $scope.savedExams[i].split(' ').join('-'))");
              console.log(window.sessionStorage.getItem($rootScope.userid + '-svdexms:' + $scope.savedExams[i].split(' ').join('-')));
              DataStore.setExamContinue({
                subj: ($scope.savedExams[i]).split(' ')[0],
                yr: ($scope.savedExams[i]).split(' ')[1],
                vl: window.sessionStorage.getItem($rootScope.userid + '-svdexms:' + $scope.savedExams[i].split(' ').join('-'))
              });
              $scope.svdexmmodal.modalShown = false;
              $scope.gotoExam(($scope.savedExams[i]).split(' ')[0], "sscetemplate");
            }
          }
          console.log("DataStore.getSavedExams():...");
          console.log(DataStore.getSavedExams());
        };

        $scope.restartExm = function() {
          LoggingService.postTrack("restartExm");
          for(var i=0;i < $scope.savedExams.length; i++) {
            if($('#svdexmv' + i).is(':checked')) {
              console.log('restarting exam: ' + $scope.savedExams[i]);
              DataStore.setExamRestart({
                subj: ($scope.savedExams[i]).split(' ')[0],
                yr: ($scope.savedExams[i]).split(' ')[1]
              });
              $scope.svdexmmodal.modalShown = false;
              $scope.gotoExam(($scope.savedExams[i]).split(' ')[0], "sscetemplate");
            }
          }
        };

        $scope.cancelExm = function() {
          LoggingService.postTrack("cancelExm");
          console.log('You have selected to cancel some saved exams.');
          $scope.savedExams = DataStore.getSavedExams();
          console.log("$scope.savedExams:....");
          console.log($scope.savedExams);
          for(var i=0;i < $scope.savedExams.length; i++) {
            if($('#svdexmv' + i).is(':checked')) {
              DataStore.removeSavedExam($scope.savedExams[i]);
            }
          }
          $scope.svdexmmodal.modalShown = false;
        };

        $scope.inTestcenter();

        $timeout(function(){
          HeaderService.setTab(1);
          if($rootScope.rtscore==true) { 
            $('#rtscore').prop('checked', true);
          } else {
            $('#rtscore').prop('checked', false);
          }
          LoggingService.postTrack("tstc");
        }, 100);

        $scope.gotoExam = function(subj, url) {
          LoggingService.postTrack("gotoExam" + subj);
          $rootScope.currentSubject = subj;
          console.log('Sscetemplate link for ' + subj + ' clicked!');
          console.log('baseRoute + url is: ' + baseRoute + url);
          $location.path(baseRoute + url);
        };

        $scope.examsubjects = [
          {
            name: 'Physics',
            image: 'physics.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Chemistry',
            image: 'chemistry.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Mathematics',
            image: 'genmaths.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Economics',
            image: 'economics.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Biology',
            image: 'biology.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1992','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'English',
            image: 'english.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Geography',
            image: 'geography.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Literature in English',
            image: 'literature.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Commerce',
            image: 'commerce.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'AgricSci',
            image: 'agriculture.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          },
          {
            name: 'Government',
            image: 'government.png',
            href: 'sscetemplate',
            examlist: ['SSCE','GCE','NECO'],
            availyears: ['1988','1989','1990','2015'],
            bgcolor: '#F4F6F6'
          }
          // {
          //   name: 'Mathematics',
          //   image: 'genmaths.png',
          //   href: 'jamb_genmaths',
          //   examlist: ['JAMB'],
          //   availyears: ['1988','1989','1990','1991','1992','1993','1994','1995','1996','1997','1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015'],
          //   bgcolor: '#A9CCE3'
          // },
          // {
          //   name: 'Physics',
          //   image: 'physics.png',
          //   href: 'jamb_physics',
          //   examlist: ['JAMB'],
          //   availyears: ['1988','1989','1990','1991','1992','1993','1994','1995','1996','1997','1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015'],
          //   bgcolor: '#A9CCE3'
          // },
          // {
          //   name: 'Chemistry',
          //   image: 'chemistry.png',
          //   href: 'jamb_chemistry',
          //   examlist: ['JAMB'],
          //   availyears: ['1988','1989','1990','1991','1992','1993','1994','1995','1996','1997','1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015'],
          //   bgcolor: '#A9CCE3'
          // },
          // {
          //   name: 'Biology',
          //   image: 'biology.png',
          //   href: 'jamb_biology',
          //   examlist: ['JAMB'],
          //   availyears: ['1988','1989','1990','1991','1992','1993','1994','1995','1996','1997','1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015'],
          //   bgcolor: '#A9CCE3'
          // }
        ];

    }
})();