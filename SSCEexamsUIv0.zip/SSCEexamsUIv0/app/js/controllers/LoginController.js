(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('LoginController', LoginController);

    // LoginController.$inject = ['$scope', '$log', '$controller', '$rootScope', 'AuthService', 'DataStore', 'growl', '$location', 'window'];

    /* @ngInject */
    function LoginController($scope, $log, $controller, $rootScope, $timeout, AuthService, DataStore, ApiService, growl, $location, window) {

        $controller('BaseController', { $scope: $scope });

        $scope.title = "Login to SSCEexams";
        $scope.username = '';
        $scope.pword = '';
        $scope.email = '';
        $scope.spinnershow = 'hide';
        $rootScope.login = false;
        window.sessionStorage.act = '';
        $rootScope.token = '';

        $scope.disabletray = function() {
            $('#righttray ul').addClass("hide");
        };

        $scope.logout = function() {
            console.log("Clearing house...");
            window.sessionStorage.clear();
            window.localStorage.clear();            
        };

        $scope.cognitoLogin = function() {
            console.log("Entering $scope.cognitoLogin()...");          
            // Registering a user with the application. One needs to create a CognitoUserPool object by providing a UserPoolId and 
            // a ClientId and signing up by using a username, password, attribute list, and validation data.
            var poolData = {
                UserPoolId : 'us-east-1_jpDRDrDiE',
                ClientId : '6gjfgkthei04sv75oloqmsbsqm'
            };
            var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
            console.log("userPool");
            console.log(userPool);
            // here are the User sign up details
            var username = $scope.rusername;
            var email = $scope.remail;
            var phone = $scope.rphone;
            var password = $scope.rpword;
            $scope.pword = $scope.rpword;
            $scope.email = $scope.remail;
            window.sessionStorage.rusername = $scope.rusername;
            window.sessionStorage.remail = $scope.remail;
            window.sessionStorage.rpword = $scope.rpword;
            window.localStorage.rusername = $scope.rusername;
            window.localStorage.remail = $scope.remail;
            window.localStorage.rpword = $scope.rpword;
            
            console.log("Registering user: " + username + ", phone: " + phone);

            var attributeList = [];
        
            var dataEmail = {
                Name : 'email',
                Value : email
            };
        
            var dataPhoneNumber = {
                Name : 'phone_number',
                Value : '+128012345678'
            };
            var attributeEmail = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(dataEmail);
            var attributePhoneNumber = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(dataPhoneNumber);
        
            attributeList.push(attributeEmail);
            attributeList.push(attributePhoneNumber);
        
            userPool.signUp(username, password, attributeList, null, function(err, result){
                $rootScope.username = username;
                $rootScope.password = password;
                // $scope.regDtbl($rootScope.username, $rootScope.password);
                if (err) {
                    console.error(err);
                    if(err.message == "User already exists") {
                        $("#regfailreg").removeClass("hide");
                        $timeout(function() {
                            $("#regfailreg").addClass("hide");
                        }, 5000);
                    } else {
                        $scope.userreg = 'User Registration failed!';
                        $("#regfailregfail").removeClass("hide");
                        $timeout(function() {
                            $("#regfailregfail").addClass("hide");
                        }, 5000);
                    }                    
                } else {
                    var cognitoUser = result.user;
                    console.log('Registered username is: ' + cognitoUser.getUsername());
                    $("#regpassreg").removeClass("hide");
                    $timeout(function() {
                        $("#regpassreg").addClass("hide");
                        $location.path('login');
                    }, 5000);
                }
            });
        };

        $scope.resendconfirmcode = function() {
            if (($scope.ausername == "") || (!$scope.ausername)) {
                console.log("Username is required");
                $("#regfailunameconf").removeClass("hide");
                $timeout(function() {
                    $("#regfailunameconf").addClass("hide");
                }, 4000); 
                return;
            }
            var poolData = {
                UserPoolId : 'us-east-1_jpDRDrDiE',
                ClientId : '6gjfgkthei04sv75oloqmsbsqm'
            };
            
            var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
            var userData = {
                Username : $scope.ausername,
                Pool : userPool
            };
            
            var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
            cognitoUser.resendConfirmationCode(function(err, result) {
                if (err) {
                    console.log(err);
                    $("#regfailresendconf").removeClass("hide");
                    $timeout(function() {
                        $("#regfailresendconf").addClass("hide");
                    }, 5000); 
                    return;
                }
                console.log('call result: ' + result);
                $("#regpassresendconf").removeClass("hide");
                $timeout(function() {
                    $("#regpassresendconf").addClass("hide");
                    $location.path('login');
                }, 5000); 
            });
        };

        $scope.confirmcode = function() {
            if (($scope.ausername == "") || (!$scope.ausername)) {
                console.log("Username is required");
                $("#regfailunamecodeconf").removeClass("hide");
                $timeout(function() {
                    $("#regfailunamecodeconf").addClass("hide");
                }, 4000); 
                return;
            }
            // Confirming a registered, unauthenticated user using a confirmation code received via SMS
            var poolData = {
                UserPoolId : 'us-east-1_jpDRDrDiE',
                ClientId : '6gjfgkthei04sv75oloqmsbsqm'
            };
            
            var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
            var userData = {
                Username : $scope.ausername,
                Pool : userPool
            };
            
            var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
            cognitoUser.confirmRegistration($scope.acode, true, function(err, result) {
                if (err) {
                    console.log(err);
                    $("#regfailconf").removeClass("hide");
                    $timeout(function() {
                        $("#regfailconf").addClass("hide");
                    }, 5000); 
                    return;
                }
                console.log('call result....');
                console.log(result);
                console.log("finished......");
                 
                $("#regpassunamecodeconf").removeClass("hide");
                $timeout(function() {
                    $("#regpassunamecodeconf").addClass("hide");
                    $location.path('login');
                }, 5000);               
            });            
        };

        $scope.thelogin = function() {
            $('#signupcard').addClass('hide');
            $('#logincard').removeClass('hide');
            $('#forgotcard').addClass('hide');
            $('#enterusercode').addClass('hide');

            $("#formUsername").removeClass('redborder');
            $("#formPassword").removeClass('redborder');
        };

        $scope.entercode = function() {
            $('#enterusercode').removeClass('hide');
            $('#signupcard').addClass('hide');
            $('#logincard').addClass('hide');
            $('#forgotcard').addClass('hide');

            $("#acode").removeClass('redborder');

            $scope.acode = '';
        };

        $scope.thesignUp = function() {
            $('#signupcard').removeClass('hide');
            $('#logincard').addClass('hide');
            $('#forgotcard').addClass('hide');
            $('#enterusercode').addClass('hide');

            $("#arusername").removeClass('redborder');
            $("#aremail").removeClass('redborder');
            $("#arpword").removeClass('redborder');
            $("#arrpword").removeClass('redborder');

            $scope.rusername = '';
            $scope.remail = '';
            $scope.rpword = '';
            $scope.rrpword = '';
        };

        $scope.theforgot = function() {
            $('#signupcard').addClass('hide');
            $('#logincard').addClass('hide');
            $('#forgotcard').removeClass('hide');
            $('#enterusercode').addClass('hide');

            $("#fUsername").removeClass('redborder');
            $("#fEmailaddy").removeClass('redborder');

            $scope.fpusername = '';
            $scope.fpemail = '';
        };

        $scope.showSchform = function() {
            $location.path('registersch'); 
        };

        $scope.gotoLogin = function() {
            $scope.thelogin();
        };

        $scope.loginFail = function(cmmt) {
            $scope.userlogin = cmmt;
            $("#loginfail").removeClass("hide");
            $timeout(function() {
                $("#loginfail").addClass("hide");
            }, 5000);
        };

        $scope.fpwordFail = function(cmmt) {
            $scope.userforgot = cmmt;
            $("#forgotfail").removeClass("hide");
            $timeout(function() {
                $("#forgotfail").addClass("hide");
            }, 5000);
        };

        $scope.sendForgot = function() {
            if (($scope.fpusername == '') || ($scope.fpemail == '')) {
                $scope.fpwordFail('Username and Email are both Required!');
            } else if (!$scope.isEmail($scope.fpemail)) {
                $scope.fpwordFail('Enter a Valid Email!');
            } else {
                $scope.userForgotPassword();
            }
        };

        $scope.convertr = function(val) {
            $rootScope.user = val;
            console.log("$rootScope.user:");
            console.log($rootScope.user);
        };

        $scope.letUserIn = function() {
            console.log("ApiService.postLoginForm----");
            ApiService.postLoginForm({
                uname: $scope.username,
                pwd: $scope.pword
            }).then(function(response) {
                console.log("response=====");
                console.log(response);
                if (response.password == $scope.pword) {
                    console.log('User Authenticated successfully.');
                    $scope.convertr(response);
                    window.sessionStorage.userprofile = response;
                    window.sessionStorage.userid = $scope.username;
                    DataStore.setUserProfile(JSON.stringify(response));
                    $rootScope.login = true;
                    $rootScope.userid = $scope.username;
                    $rootScope.userpwd = $scope.pword;
                    response.password = null;
                    if (!DataStore.setUserSchProfile()) {
                        ApiService.getUserSchDetails($rootScope.userid).then(function(response) {
                            console.log("ApiService.getUserSchDetails: ");
                            console.log(response);
                            DataStore.setUserSchProfile(JSON.stringify(response));
                        })
                    }
                    console.log(JSON.parse(DataStore.getUserProfile()));
                    DataStore.setExams();
                    $location.path('dashboard');
                } else {
                    $scope.loginFail('Log In Failed!');
                }
            }, function(error) {
                $scope.loginFail('Invalid User Parameters!');
            });
        };

        $scope.registerNow = function() {
            $scope.userRegist(window.sessionStorage.username, window.sessionStorage.email, "122334455", window.sessionStorage.password);
            $scope.letUserIn();
        };

        $scope.userLogin = function() {
            if (($scope.username == '') || ($scope.pword == '')) {
                $scope.loginFail('Username and Password Required to Log in!');
            } else {
                $scope.spinnershow = '';
                var authenticationData = {
                    Username : $scope.username,
                    Password : $scope.pword
                };
                var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
                var poolData = {
                    UserPoolId : 'us-east-1_jpDRDrDiE',
                    ClientId : '6gjfgkthei04sv75oloqmsbsqm'
                };
                var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
                var userData = {
                    Username : $scope.username,
                    Pool : userPool
                };
                var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
                // start
                if (cognitoUser != null) {
                    cognitoUser.getSession(function(err, session) {
                        if (err) {
                            console.log(err);
                            return;
                        }
                        console.log(session);
                        console.log("session validity: " + session.isValid());
                        console.log("userPool.getCurrentUser()...");
                        console.log(userPool.getCurrentUser());
                    });
                }
                // end
                cognitoUser.authenticateUser(authenticationDetails, {
                    onSuccess: function (result) {
                        console.log(result);
                        console.log(result.accessToken);
                        window.sessionStorage.username = result.accessToken.payload.username;
                        window.sessionStorage.email = result.idToken.payload.email;
                        window.sessionStorage.password = $scope.pword;
                        console.log(result.idToken);
                        console.log(result.refreshToken);
                        console.log('access token + ' + result.getAccessToken().getJwtToken());
                        // window.sessionStorage.act = result.getAccessToken().getJwtToken();
                        window.sessionStorage.act = '' + result.idToken.jwtToken + '';
                        window.localStorage.act = result.getAccessToken().getJwtToken();
                        $rootScope.token = result.getAccessToken().getJwtToken();
                        window.sessionStorage.idtoken = result.getIdToken().getJwtToken();            
                        //POTENTIAL: Region needs to be set if not already set previously elsewhere.
                        AWS.config.region = 'us-east-1';                   
                        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                            IdentityPoolId : 'us-east-1:ffbd865e-1ff4-4f1d-83dd-e5b6a670a255',
                            Logins : {
                                'cognito-idp.us-east-1.amazonaws.com/us-east-1_jpDRDrDiE' : result.getIdToken().getJwtToken()
                            }
                        });
                        // User successfully logged in, Retrieve user attributes for an authenticated user to sessionStorage
                        cognitoUser.getUserAttributes(function(err, result) {
                            if (err) {
                                console.error(err);
                            return;
                            }
                            console.log('Getting ' + result.length + ' User attributes...');
                            for (var i = 0; i < result.length; i++) {
                                console.log('User attribute: ' + result[i].getName() + ' has value: ' + result[i].getValue());
                            }
                        });                
                        //refreshes credentials using AWS.CognitoIdentity.getCredentialsForIdentity()
                        // AWS.config.credentials.refresh((error) => {
                        AWS.config.credentials.refresh(function(error, result) {
                            if (error) {
                                console.log("Failed refreshing credentials...");
                                console.error(error);
                            } else {
                                console.log("ApiService.registerUser Done...");
                                // Now try to register user with Dtbl
                                console.log("calling $scope.userRegist($scope.ausername, $scope.email, '122334455', $rootScope.password):...");
                                console.log("$scope.ausername: " + window.sessionStorage.username);
                                console.log("$scope.email: " + window.sessionStorage.email);
                                console.log("$scope.pword: " + window.sessionStorage.password);

                                // $scope.userRegist(window.sessionStorage.username, window.sessionStorage.email, "122334455", window.sessionStorage.password);

                                console.log("Authenticate User ApiService.postLoginForm----");
                                var pdetails = ApiService.postLoginForm({
                                    uname: $scope.username,
                                    pwd: $scope.pword
                                }).then(function(response) {
                                    console.log("responseddddd");
                                    console.log(response);
                                    if(response.status == 'active') {
                                        console.log('User Authenticated successfully.');
                                        $scope.convertr(response);
                                        window.sessionStorage.userprofile = response;
                                        window.sessionStorage.userid = response.username;
                                        DataStore.setUserProfile(JSON.stringify(response));
                                        $rootScope.login = true;
                                        $rootScope.userid = $scope.username;
                                        $rootScope.userpwd = $scope.pword;
                                        response.password = null;
                                        if (!DataStore.setUserSchProfile()) {
                                            ApiService.getUserSchDetails($rootScope.userid).then(function(response) {
                                                console.log("ApiService.getUserSchDetails: ");
                                                console.log(response);
                                                DataStore.setUserSchProfile(JSON.stringify(response));
                                            })
                                        }
                                        console.log(JSON.parse(DataStore.getUserProfile()));
                                        DataStore.setExams();
                                        $scope.spinnershow = 'hide';
                                        $location.path('dashboard');
                                    } else {
                                        console.log("calling $scope.registerNow()------------");
                                        $scope.spinnershow = 'hide';
                                        $scope.registerNow();
                                    }
                                }, function(error) {
                                    $scope.registerNow();
                                });
                            }
                        });
                    },                    
                    onFailure: function(err) {
                        console.log("onFailure occurred!");
                        $scope.loginFail('Log In Failed!');
                        console.log(err);
                        if(err === 'Error: Password reset required for the user') {
                            $scope.userlogin = 'Incorrect username or password';
                        }
                        if(err === 'Error: Password reset required for the user') {
                            $scope.userlogin = 'Please check email for Password reset link';
                        }
                        
                        $("#loginfail").removeClass("hide");
                        $timeout(function() {
                            $("#loginfail").addClass("hide");
                            $scope.spinnershow = 'hide';
                        }, 3000);
                    }                    
                });
            }
        };

        $scope.userLoginn = function() {
            window.sessionStorage.clear();
            window.localStorage.clear();
            if (($scope.username == '') || ($scope.pword == '')) {
                $scope.loginFail('Username and Password Required to Log in!');
            } else if (($scope.username) && ($scope.pword)) {
                $scope.spinnershow = '';
                ApiService.postLoginForm({
                    uname: $scope.username,
                    pwd: $scope.pword
                }).then(function(response) {
                    if (response.password == $scope.pword) {
                        console.log('User Authenticated successfully.');
                        $rootScope.token = response.id;
                        $scope.convertr(response);
                        window.sessionStorage.act = response.id;
                        window.sessionStorage.userprofile = response;
                        window.sessionStorage.userid = response.username;
                        DataStore.setUserProfile(JSON.stringify(response));
                        $rootScope.login = true;
                        $rootScope.userid = response.username;
                        $rootScope.userpwd = response.password;
                        response.password = null;
                        if (!DataStore.setUserSchProfile()) {
                            ApiService.getUserSchDetails($rootScope.userid).then(function(response) {
                                console.log("ApiService.getUserSchDetails: ");
                                console.log(response);
                                DataStore.setUserSchProfile(JSON.stringify(response));
                            })
                        }
                        console.log(JSON.parse(DataStore.getUserProfile()));
                        $scope.spinnershow = 'hide';
                        $location.path('dashboard');
                    } else {
                        $scope.loginFail('Log In Failed!');
                        $scope.spinnershow = 'hide';
                    }
                }, function(error) {
                    $scope.loginFail('Invalid User Parameters!');
                    $scope.spinnershow = 'hide';
                });
            } else {
                $scope.loginFail('Log In Failed!');
                $scope.spinnershow = 'hide';
            }
        };

        $scope.isEmail = function(email) {
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(email);
            // return true;
        };

        $scope.regFail = function(cmmt) {
            $scope.userreg = cmmt; //'Registration failed, Username Already Exists!';
            $("#regfail").removeClass("hide");
            $timeout(function() {
                $("#regfail").addClass("hide");
            }, 5000);
        };

        $scope.regPass = function(cmmt) {
            $scope.userreg = cmmt; // 'Registration succeeded, Log In to proceed!'
            $("#regpass").removeClass("hide");
            $timeout(function() {
                $("#regpass").addClass("hide");
                // create an empty profile for this user below
                // ApiService.postUserProfileDetails(username, uemail);
                // $location.path('login');
            }, 5000);            
        };

        $scope.regPassVal = function(username, uemail) {
            $scope.userreg = 'Registration succeeded, Log In to proceed!';
            $("#regpass").removeClass("hide");
            $timeout(function() {
                $("#regpass").addClass("hide");
                // create an empty profile for this user below
                // ApiService.postUserProfileDetails(username, uemail);
                // $location.path('login');
            }, 5000);            
        };

        $scope.fpwdFail = function() {
            $scope.userforgot = 'Password Recovery Failed, Please Try Again!';
            $("#forgotfail").removeClass("hide");
            $timeout(function() {
                $("#forgotfail").addClass("hide");
            }, 5000);
        };

        $scope.fpwdPass = function() {
            $scope.userforgot = 'Password Recovery succeeded, Check your Email!';
            $("#forgotfail").removeClass("hide");
            $timeout(function() {
                $("#forgotfail").addClass("hide");
            }, 5000);
        };

        $scope.userRegist = function(rusername, remail, rphone, rpword) {
            console.log('userRegist clicked with ');
            console.log('Username: ' + rusername);
            console.log('Email: ' + remail);
            console.log('Phone: ' + rphone);
            console.log('Password: ' + rpword);
            // first check if user is not registered
            ApiService.registerUser({
                uname: rusername,
                email: remail,
                phoneno: rphone,
                pword: rpword
            }).then(function(response) {
                console.log("response:----");
                console.log(response);
                if (response.username == rusername) {
                    console.log("User registration successful---");
                    $scope.regPassVal(rusername, remail);
                } else {
                    $scope.regFail('User Registration failed, please change password or Choose a different Username!');
                }
            });
        };

        $scope.userRegister = function() {
            console.log('userRegister clicked with ');
            $scope.cognitoLogin();
        };

        $scope.userForgotPassword = function() {
            console.log('userForgotPassword clicked with ');
            console.log('Username: ' + $scope.fpusername);
            console.log('Email: ' + $scope.fpemail);
            ApiService.forgotpwdUser({
                uname: $scope.fpusername,
                email: $scope.fpemail
            });
            // $scope.fpwdFail();
            $scope.fpwdPass();
        };

        $scope.checkTxts = function() {
            if ($scope.rpword === $scope.rrpword) {
                $(".ppword").removeClass('redborder');
            } else {
                $(".ppword").addClass('redborder');
            }
        };

        $scope.checkEml = function() {
            if (!$scope.isEmail($scope.remail)) {
                $("#aremail").addClass('redborder');
            } else {
                $("#aremail").removeClass('redborder');
            }
        };

        $scope.checkUname = function() {
            if ($scope.rusername == '') {
                $("#arusername").addClass('redborder');
            } else {
                $("#arusername").removeClass('redborder');
            }
        };

        $('#arusername').on('keyup', function(e) {
            $scope.checkUname();
        });

        $('#aremail').on('keyup', function(e) {
            // console.log('Email is: ' + $scope.remail); 
            $scope.checkEml();
        });

        $('#arrpword').on('keyup', function(e) {
            // console.log('Password 2: ' + $scope.rrpword); 
            $scope.checkTxts();
        });

        $('#arpword').on('keyup', function(e) {
            // console.log('Password 1: ' + $scope.rpword); 
            $scope.checkTxts();
        });

        $scope.userForgot = function() {
            console.log('userForgot clicked with ');
        };

        $scope.loginUser = function(u, p) {
            // send the username and password to the DB to check if this user is registered
            return AuthService.postLoginForm({
                uname: u,
                pwd: p
            });
        };

        $scope.signupUser = function(u, p) {
            // send the username and password to the DB to check if this user is registered
            return AuthService.postLoginForm({
                uname: u,
                pwd: p
            });
        };

        $scope.disabletray();
    }
})();