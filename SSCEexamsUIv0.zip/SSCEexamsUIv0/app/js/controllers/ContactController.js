(function() {
      'use strict';

      angular
        .module('ssceexamsuiApp')
        .controller('ContactController', ContactController);

      // ContactController.$inject = ['$scope', '$log', '$controller', '$rootScope', 'ConfigService', 'ApiService', 'growl', '$location', '$timeout', 'HeaderService'];

      /* @ngInject */
      function ContactController($scope, $log, $controller, $rootScope, ConfigService, ApiService, growl, $location, $timeout, HeaderService, LoggingService) {

            $controller('BaseController', {$scope: $scope});
            $rootScope.baseRoute = '';
            var baseRoute = '';
            $scope.contactmodal = {
                modalShown: false
            };
            $scope.modaltext = "";
            $scope.modalheader = "";

            $scope.continueExm = function() {
              $scope.contactmodal.modalShown = false;
            };

            $scope.inContactUs = function() {
                  console.log('Now in the Contact Us page!');
            };

            $scope.inContactUs();

            $scope.setModalTexts = function(hdr, bdy) {
              $scope.modalheader =hdr;
              $scope.modaltext = bdy;
              $scope.contactmodal.modalShown = true;           
            };

            $scope.isEmail = function(email) {
              var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              return regex.test(email);
            };

            $('#fname').on('keyup', function(e) {
              if(($('#fname').val() != "") && ($('#fname').val() != null)) {
                $('#fname').removeClass('redborder');
              }
            });

            $('#lname').on('keyup', function(e) {
              if(($('#lname').val() != "") && ($('#lname').val() != null)) {
                $('#lname').removeClass('redborder');
              }
            });

            $('#email').on('keyup', function(e) {
              if(($('#email').val() != "") && ($('#email').val() != null)) {
                $('#email').removeClass('redborder');
              }
            });

            $('#phone').on('keyup', function(e) {
              if(($('#phone').val() != "") && ($('#phone').val() != null)) {
                $('#phone').removeClass('redborder');
              }
            });

            $('#note').on('keyup', function(e) {
              if(($('#note').val() != "") && ($('#note').val() != null)) {
                $('#note').removeClass('redborder');
              }
            });

            $scope.sendForm = function() {
              LoggingService.postTrack("cc-sendform");
              $log.info('Sending form details to server');
              if ($('#fname').val() == "") {
                $('#fname').addClass('redborder');
              } else if ($('#lname').val() == "") {
                $('#lname').addClass('redborder');
              } else if ($('#email').val() == "") {
                $('#email').addClass('redborder');
              } else if ($('#phone').val() == "") {
                $('#phone').addClass('redborder');
              } else if ($('#note').val() == "") {
                $('#note').addClass('redborder');
              } else if (!$scope.isEmail($('#email').val())) {
                $("#email").addClass('redborder');
              } else {
                var msg = {
                  username: $scope.userid,
                  firstname: $('#fname').val(),
                  lastname: $('#lname').val(),
                  email: $('#email').val(),
                  phone: $('#phone').val(),
                  cname: Date(),
                  country: $('#country').val(),
                  jtitle: $('#jtitle').val(),
                  note: $('#note').val(),
                  createdAt: 1,
                  updatedAt: 1
                };
                console.log('msg is: ');
                console.log(msg);
                $scope.sendContactInfo(msg);
              }
            };

            $scope.clearForm = function() {
              LoggingService.postTrack("cc-clrform");
              $('#fname').val('');
              $('#lname').val('');
              $('#email').val('');
              $('#phone').val('');
              $('#cname').val('');
              $('#country>option:eq(0)').prop('selected', true);
              $('#jtitle').val('');
              $('#note').val('');            
            };

            $timeout(function(){
                 HeaderService.setTab(4);
            }, 100);

            $scope.sendContactInfo = function(msg) {
              LoggingService.postTrack("cc-sendccinfo");
              ApiService.sendContactInfo(msg)
                .then(function(response) {
                  $scope.clearForm();
                  console.log('Sending the contact us form details: ');
                  if(response) {
                    $scope.modalheader = "Submission Successful....Thanks";
                    $scope.modaltext = "Our customer service staff will contact you soon regarding your submission.";
                    $scope.contactmodal.modalShown = true;
                    $scope.clearForm();
                  }
                }, function(error) {
                    $scope.modalheader = "Submission failed.";
                    $scope.modaltext = "Please Click Contact Us button again or try again later.";
                    $scope.contactmodal.modalShown = true;             
                }
              );
            };
      }     
})();
