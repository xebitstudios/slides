(function() {
    'use strict';

    angular
        .module('ssceexamsuiApp')
        .controller('RegisterSchoolController', RegisterSchoolController);

    // RegisterSchoolController.$inject = ['$scope', '$log', '$controller', '$rootScope', 'ConfigService', 'ApiService', 'growl', '$location', 'LoggingService'];

    /* @ngInject */
    function RegisterSchoolController($scope, $log, $controller, $rootScope, $timeout, ConfigService, ApiService, HeaderService, growl, $location, LoggingService) {

        // $controller('BaseController', {$scope: $scope});
        

        $scope.title = "Register your School to SSCEexams";
        $scope.succ = 'errs';

        $scope.schname = '';
        $scope.schooladdy = '';
        $scope.schuname = '';
        $scope.schpwd = '';
        $scope.schctperson = '';
        $scope.schemail = '';
        $scope.schctphone = '';
        $scope.schadd = '';
        $scope.username = ConfigService.getUserId();//$rootScope.userId;

        $scope.schRegShow = function(cmmt, succval) {
            $scope.schregval = cmmt;
            $scope.succ = succval;
            $("#schregval").removeClass("hide");
            $timeout(function(){
                $("#schregval").addClass("hide");
                if(succval == 'succ') {
                    $location.path('dashboard');
                }
            }, 5000);
        };

        $scope.registernewschool = function() {
            $scope.username = Date().split(' ')[0] + Date().split(' ')[1] + Date().split(' ')[2] + Date().split(' ')[3] + Date().split(' ')[4].replace(':','').replace(':','');
            $scope.schpwd = $scope.username;
            console.log('$scope.username is: ' + $scope.username);
            console.log('$scope.schname is: ' + $scope.schname);
            console.log('$scope.schooladdy is: ' + $scope.schooladdy); 
            console.log('$scope.schuname is: ' + $scope.schuname);
            console.log('$scope.schpwd is: ' + $scope.schpwd); 
            console.log('$scope.schctperson is: ' + $scope.schctperson);
            console.log('$scope.schemail is: ' + $scope.schemail); 
            console.log('$scope.schctphone is: ' + $scope.schctphone);
            console.log('$scope.schadd is: ' + $scope.schadd);
            console.log($('#prek').is(':checked'));
            console.log($('#kdgrt').is(':checked'));
            console.log($('#nandp').is(':checked'));
            console.log($('#secon').is(':checked'));
            console.log($('#tert').is(':checked'));
            console.log($('#schfree').is(':checked') ? "yes" : "no");
            console.log($('#schbasic').is(':checked') ? "yes" : "no");
            console.log($('#schprm').is(':checked') ? "yes" : "no");

            if($scope.schname != '' && $scope.schooladdy != '') {
                console.log('Register form submitted!');
                LoggingService.postTrack("regsch");
                ApiService.registerSchool({
                    username: $scope.username,
                    schname: $scope.schname,
                    schooladdy: $scope.schooladdy,
                    schpwd: $scope.schpwd,
                    schctperson: $scope.schctperson || 'NA',
                    schemail: $scope.schemail || 'NA',
                    schctphone: $scope.schctphone || 'NA',
                    schadd: $scope.schadd || 'NA',
                    subscriptionstartdate: $scope.subscriptionstartdate || 'NA',
                    subscriptionenddate: $scope.subscriptionenddate || 'NA',
                    createdAt: $scope.createdAt || 1,
                    accesscode: $scope.accesscode || 'NA',
                    updatedAt: $scope.updatedAt || 1,
                    prek: $('#prek').is(':checked'),
                    kdgrt: $('#kdgrt').is(':checked'),
                    nandp: $('#nandp').is(':checked'),
                    secon: $('#secon').is(':checked'),
                    tert: $('#tert').is(':checked'),
                    schfree: $('#schfree').is(':checked') ? "yes" : "no",
                    schbasic: $('#schbasic').is(':checked') ? "yes" : "no",
                    schprm: $('#schprm').is(':checked') ? "yes" : "no"
                }).then(function(response) {
                    if(response) {
                        console.log('Application Submitted Successfully, We will Contact You Soon.');
                        $scope.schRegShow('Application Submitted Successfully, We will Contact You Soon.', 'succ');                    
                    }
                    $location.path(baseRoute + 'login');
                }, function(error) {
                    $scope.schRegShow('School Application Failed, Please Try Again!', 'errs');
                });
            } else {
                $scope.schRegShow('School Username, Name and Address are Required to Apply, Please Try Again!', 'errs');
            }
        };

        $scope.cancel = function() {
            $location.path($scope.baseRoute + '/signup');
        };

        $timeout(function(){
            HeaderService.setTab(6);
        }, 300);
    }

     
})();
