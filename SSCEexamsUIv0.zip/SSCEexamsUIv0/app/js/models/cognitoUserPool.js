var CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool; // When using loose Javascript files:

// make this available to our users in our application
module.exports = CognitoUserPool;