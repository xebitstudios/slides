(function() {
    'use strict';

    angular
        .module('constantsModule')
        .constant('_', _)
        .constant('constant', {
            APP_NAME: 'SSCE Exams UI',
            API_HOST: 'http://localhost:8065',
            API_URI: 'https://0n9jbuakcc.execute-api.us-east-1.amazonaws.com/dev/'
        });

})();
