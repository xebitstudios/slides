(function() {
    'use strict';  
    ssceexamsuiApp
      .directive('fileUpload', function () {
          return {
              restrict: 'A',
              scope: { fileUpload: '&' },
              replace: true,
              templateUrl: '<div><input type="file" id="file" /></div>',
              link: function(scope, ele, attrs) {
                  ele.bind('change', function() {
                      var file = ele[0].files;
                      if (file){ 
                          scope.fileUpload({
                            files: file
                        })
                      };
                  })
              }
          }
      });    
})();
