module.exports = {
    // static pages / api address
    'dev': 'http://localhost:8065',
    'qa': '',
    'prod': '',
    // secret is used when we create and verify JSON Web Tokens
    'secret': 'this is the ssceexams ui app',
    'LoggingAPI': '192.168.1.144:8066/api'
};