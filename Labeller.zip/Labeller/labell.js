console.log('running labell.js...');
// register onchange function
let input = document.querySelector('input');
let textarea = document.querySelector('textarea');

document
  .getElementById('files')
  .onchange = function() {
  	let file = this.files[0];
  	console.log(file);
  	
  	let reader = new FileReader();
  	reader.onload = function() {
  		// console.log(this.result);
  		const filee = this.result;
  		const lines = filee.split(/\r\n|\n/);
  		textarea.value = lines.join('\n');
  	}
  	reader.onerror = (e) => alert(e.target.error.name);

  	// read the file
  	reader.readAsText(file);
  	setTimeout(() => {  
  		var attTxt = document.getElementById("txtAr").value;
		localStorage.setItem("textVal", attTxt);		
  	}, 3000);
}
