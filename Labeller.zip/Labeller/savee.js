console.log('running savee.js...');

let arry = [];
let idx = 0;
let csvData = [];

function splitFile() {
	// let idx = 0;
	let finalstr = "";
	let txt = localStorage.getItem("textVal");
	arry = txt.split(/\s*[,\n.]+\s*/);
	console.log("arry length: " + arry.length);
	for(let a=0;a<arry.length;a++) {
		if(arry[a].length > 0) {
			finalstr = finalstr + arry[a] + '\n';
			console.log("arry[" + a + "]: " + arry[a]);
		}
	}
	let textareaOut = document.querySelector('textarea');
	textareaOut.value = finalstr;
	btn.disabled = true;
	document.getElementById('mySentence').innerHTML = "Click text to start classification of sentences.";
}
  
var btn = document.getElementById("myBtn");
btn.addEventListener("click", splitFile);

var sbtn = document.getElementById("mySentence");
sbtn.addEventListener("click", setSentence);

function classifyText(indx) {
	let clssTxt = document.getElementById('mySentence').innerHTML;
	// console.log("Classification: " + indx + "***" + clssTxt);
	if(indx != "INVALID-TEXT") {
		// if((localStorage.getItem("s"+idx))==null) {
		// 	console.log('checking... ' + localStorage.getItem("s"+idx));
		// } else {
			localStorage.setItem("s"+idx, indx + "***" + clssTxt);
			addArray(clssTxt, indx);
		// }
	}
	idx = idx+1;
	setSentence();
}

function setSentence() {
	let clssTxt = document.getElementById('mySentence').innerHTML = arry[idx];
}

function addArray(txt, clss) {
	csvData.push(new Array(txt, clss));
}

function download_csv_file() {  
  
    //define the heading for each row of the data  
    var csv = 'Text,Classification\n';  
      
    csvData.forEach(function(row) {  
            csv += row.join(',');  
            csv += "\n";  
    });  
   
    //display the created CSV data on the web browser   
    document.write(csv); 

    var hiddenElement = document.createElement('a');  
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);  
    hiddenElement.target = '_blank';  
      
    //provide the name for the CSV file to be downloaded  
    hiddenElement.download = 'Classified Sentences.csv';  
    hiddenElement.click();  
}

